import concurrent.futures
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from zipfile import ZipFile

BASE = Path(__file__).resolve().parent
ROOT = BASE / "project/MyHomeLib-R18-8.0.0-fixed-source"
OUT = BASE / "evidence/source-checks"
OUT.mkdir(parents=True, exist_ok=True)
UTC = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

with ZipFile(ROOT / "docs/release/audit-evidence-2026-10-13.zip") as evidence:
    prefix = "root-production-verified/"
    run = json.loads(evidence.read(prefix + "run.json"))
    manifest = evidence.read(prefix + "tested-sources.sha256")
    assert hashlib.sha256(manifest).hexdigest() == run["testedSourcesManifestSha256"]
    matched = []
    for line in manifest.decode().splitlines():
        digest, relative = line.split("  ", 1)
        path = ROOT / relative
        assert path.is_file(), relative
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, relative
        matched.append(relative)
    counts = dict.fromkeys(("tests", "failures", "errors", "skipped"), 0)
    modules = {}
    reports = []
    with ZipFile(io.BytesIO(evidence.read(prefix + "test-reports.zip"))) as tests:
        for name in tests.namelist():
            if not name.endswith(".xml"):
                continue
            suite = ET.fromstring(tests.read(name))
            assert suite.tag == "testsuite", name
            for key in counts:
                counts[key] += int(suite.attrib.get(key, 0))
            module = name.split("/")[0]
            modules[module] = modules.get(module, 0) + 1
            reports.append(name)
    assert counts == run["tests"], (counts, run["tests"])
    assert len(modules) == 20 and len(reports) == 671
    log = evidence.read(prefix + "maven.log").decode()
    reactor = log.split("Reactor Summary for MyHomeLib Enterprise 8.0.0:")[-1]
    assert "BUILD SUCCESS" in reactor and reactor.count("SUCCESS [") == 21

proof = {
    "verifiedUtc": UTC(),
    "rootBuildStartedUtc": run["startedUtc"],
    "rootBuildElapsedSeconds": run["elapsedSeconds"],
    "rootBuildRerunToday": False,
    "matchedManifestFiles": len(matched),
    "testedSourcesManifestSha256": run["testedSourcesManifestSha256"],
    "countsRecomputedFromRawXml": counts,
    "executedTests": counts["tests"] - counts["skipped"],
    "reportFiles": len(reports),
    "reportModules": modules,
    "reactorSuccessCount": 21,
}
(OUT / "root-build-evidence-verification.json").write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps(proof), flush=True)

CHECKS = [
    ("build-check-v7", [], 0),
    ("static_release_check", [], 0),
    ("project-hygiene-check", [], 0),
    ("empty-catch-growth-check", [], 0),
    ("source-archive-policy-test", [], 0),
    ("vendor-binary-inventory-test", [], 0),
    ("vendor-binary-inventory", ["--check"], 0),
    ("validate-language-catalogs", [], 0),
    ("check-critical-ui-localization", [], 0),
    ("supply-chain-policy-check", [], 0),
    ("static-release-source-count-test", [], 0),
    ("stage25c-search-sync-refactor-check", [], 1),
]


def check(spec):
    name, args, expected = spec
    command = [sys.executable, f"tools/{name}.py", *args]
    started = UTC()
    clock = time.monotonic()
    completed = subprocess.run(command, cwd=ROOT, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=180)
    (OUT / f"{name}.log").write_text(completed.stdout, encoding="utf-8")
    result = {"name": name, "command": command, "startedUtc": started,
              "elapsedSeconds": round(time.monotonic() - clock, 3),
              "exitCode": completed.returncode,
              "status": "PASS" if completed.returncode == 0 else "FAIL",
              "knownOpenFinding": expected != 0}
    print(json.dumps(result), flush=True)
    return result


with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(check, CHECKS))
(OUT / "checks.json").write_text(json.dumps(results, indent=2) + "\n")
unexpected = [r for r, spec in zip(results, CHECKS) if r["exitCode"] != spec[2]]
assert not unexpected, unexpected
stage_log = (OUT / "stage25c-search-sync-refactor-check.log").read_text()
assert "FolderSyncService still too large: 375" in stage_log
print("Required checks PASS; Stage 25C size finding remains OPEN_LOCAL.", flush=True)
